(self["webpackChunk"] = self["webpackChunk"] || []).push([["app"],{

/***/ "./assets/app.js":
/*!***********************!*\
  !*** ./assets/app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _app_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.scss */ "./assets/app.scss");
/* harmony import */ var _scripts_home_search__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./scripts/home/search */ "./assets/scripts/home/search.js");
/* harmony import */ var _scripts_home_search__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_scripts_home_search__WEBPACK_IMPORTED_MODULE_1__);
/*
 * Welcome to your app's main JavaScript file!
 *
 * We recommend including the built version of this JavaScript file
 * (and its CSS file) in your base layout (base.html.twig).
 */

// any CSS you import will output into a single css file (app.scss in this case)

__webpack_require__(/*! bootstrap */ "./node_modules/bootstrap/dist/js/bootstrap.esm.js");


/***/ }),

/***/ "./assets/scripts/home/search.js":
/*!***************************************!*\
  !*** ./assets/scripts/home/search.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
__webpack_require__(/*! core-js/modules/es.date.now.js */ "./node_modules/core-js/modules/es.date.now.js");
__webpack_require__(/*! core-js/modules/es.date.to-string.js */ "./node_modules/core-js/modules/es.date.to-string.js");
__webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
__webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
__webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
__webpack_require__(/*! core-js/modules/es.symbol.to-primitive.js */ "./node_modules/core-js/modules/es.symbol.to-primitive.js");
__webpack_require__(/*! core-js/modules/es.date.to-primitive.js */ "./node_modules/core-js/modules/es.date.to-primitive.js");
__webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
__webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
__webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
__webpack_require__(/*! core-js/modules/es.error.cause.js */ "./node_modules/core-js/modules/es.error.cause.js");
__webpack_require__(/*! core-js/modules/es.error.to-string.js */ "./node_modules/core-js/modules/es.error.to-string.js");
__webpack_require__(/*! core-js/modules/es.object.define-property.js */ "./node_modules/core-js/modules/es.object.define-property.js");
__webpack_require__(/*! core-js/modules/es.symbol.iterator.js */ "./node_modules/core-js/modules/es.symbol.iterator.js");
__webpack_require__(/*! core-js/modules/es.array.iterator.js */ "./node_modules/core-js/modules/es.array.iterator.js");
__webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
__webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var $ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
var HeaderSearch = /*#__PURE__*/function () {
  "use strict";

  function HeaderSearch() {
    _classCallCheck(this, HeaderSearch);
  }
  _createClass(HeaderSearch, [{
    key: "eraseAnswers",
    value: function eraseAnswers(answers) {
      $('#' + answers).empty();
    }
  }, {
    key: "setUniqSearch",
    value: function setUniqSearch(answers, uniqid) {
      $('#' + answers).attr('data-fl-search', uniqid);
    }
  }, {
    key: "searchTitle",
    value: function searchTitle(input) {
      var answers = $(input).attr('data-fl-target');
      this.eraseAnswers(answers);
      var uniqid = Date.now();
      this.setUniqSearch(answers, uniqid);
      if ($(input).val() !== "") {
        this.sendRequest(this, input, uniqid);
      }
    }
  }, {
    key: "buildCard",
    value: function buildCard(search, answers, response) {
      console.log(response);
      var card = document.createElement('div');
      card.className = "d-flex w-100 searched-product";
      var div = document.createElement('div');
      div.className = "d-flex align-items-center justify-content-center searched-image-block";
      var img = document.createElement('img');
      img.className = "mw-100 mh-100 searched-image-content";
      img.src = response.attachments.image;
      img.alt = response.code;
      div.appendChild(img);
      var link = document.createElement('a');
      link.className = "w-100 text-decoration-none fl_font-family-primary searched-link";
      link.href = "/goods/" + response.code;
      link.innerHTML = "Показать подробнее";
      card.appendChild(div);
      card.appendChild(search.buildDescription(response));
      card.appendChild(link);
      answers[0].appendChild(card);
    }
  }, {
    key: "buildDescription",
    value: function buildDescription(response) {
      var description = document.createElement('div');
      description.className = "d-flex flex-column fl_font-family-primary searched-description";
      var type = document.createElement('h2');
      type.innerHTML = response.type;
      var code = document.createElement('h1');
      code.innerHTML = response.code;
      var priceBlock = document.createElement('div');
      priceBlock.className = "d-flex justify-content-between w-100 fl_font-family-primary searched-price";
      var priceCurrency = document.createElement('p');
      priceCurrency.innerHTML = response.price.currency;
      var priceValue = document.createElement('span');
      priceValue.innerHTML = response.price.value;
      priceCurrency.appendChild(priceValue);
      var warehouseCount = document.createElement('p');
      warehouseCount.innerHTML = "шт.";
      var warehouseValue = document.createElement('span');
      warehouseValue.innerHTML = response.price.warehouse;
      warehouseCount.prepend(warehouseValue);
      priceBlock.appendChild(priceCurrency);
      priceBlock.appendChild(warehouseCount);
      description.appendChild(type);
      description.appendChild(code);
      description.appendChild(priceBlock);
      return description;
    }
  }, {
    key: "sendRequest",
    value: function sendRequest(search, input, uniqid) {
      $.ajax({
        type: "POST",
        url: "/search/full",
        data: {
          "limit": 24,
          "code": $(input).val()
        },
        enctype: 'application/json',
        dataType: 'json',
        statusCode: {
          200: function _(response) {
            if (response !== undefined) {
              if (response['search']) {
                var answers = $('#' + $(input).attr('data-fl-target'));
                for (var i = 0; i < response['search'].length; i++) {
                  if (Number($(answers).attr('data-fl-search')) !== uniqid) {
                    return;
                  }
                  search.buildCard(search, answers, response.search[i]);
                }
              }
            }
          }
        }
      });
    }
  }]);
  return HeaderSearch;
}();
var input = $("input[name=searchInput]");
if (input[0] !== undefined) {
  var search = new HeaderSearch();
  $("input[name=searchInput]").on('input', function () {
    search.searchTitle($(this));
  });
}

/***/ }),

/***/ "./assets/app.scss":
/*!*************************!*\
  !*** ./assets/app.scss ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendors-node_modules_bootstrap_dist_js_bootstrap_esm_js-node_modules_jquery_dist_jquery_js-no-e404aa"], () => (__webpack_exec__("./assets/app.js")));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDb0I7QUFFcEJBLG1CQUFPLENBQUMsb0VBQVcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1ZwQixJQUFNQyxDQUFDLEdBQUdELG1CQUFPLENBQUMsb0RBQVEsQ0FBQztBQUFDLElBRXRCRSxZQUFZO0VBQUE7O0VBQUEsU0FBQUEsYUFBQTtJQUFBQyxlQUFBLE9BQUFELFlBQUE7RUFBQTtFQUFBRSxZQUFBLENBQUFGLFlBQUE7SUFBQUcsR0FBQTtJQUFBQyxLQUFBLEVBQ2QsU0FBQUMsYUFBYUMsT0FBTyxFQUFFO01BQ2xCUCxDQUFDLENBQUMsR0FBRyxHQUFHTyxPQUFPLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDNUI7RUFBQztJQUFBSixHQUFBO0lBQUFDLEtBQUEsRUFFRCxTQUFBSSxjQUFjRixPQUFPLEVBQUVHLE1BQU0sRUFBRTtNQUMzQlYsQ0FBQyxDQUFDLEdBQUcsR0FBR08sT0FBTyxDQUFDLENBQUNJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRUQsTUFBTSxDQUFDO0lBQ25EO0VBQUM7SUFBQU4sR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQU8sWUFBWUMsS0FBSyxFQUFFO01BQ2YsSUFBSU4sT0FBTyxHQUFHUCxDQUFDLENBQUNhLEtBQUssQ0FBQyxDQUFDRixJQUFJLENBQUMsZ0JBQWdCLENBQUM7TUFFN0MsSUFBSSxDQUFDTCxZQUFZLENBQUNDLE9BQU8sQ0FBQztNQUUxQixJQUFJRyxNQUFNLEdBQUdJLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUM7TUFDdkIsSUFBSSxDQUFDTixhQUFhLENBQUNGLE9BQU8sRUFBRUcsTUFBTSxDQUFDO01BRW5DLElBQUlWLENBQUMsQ0FBQ2EsS0FBSyxDQUFDLENBQUNHLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFO1FBQ3ZCLElBQUksQ0FBQ0MsV0FBVyxDQUFDLElBQUksRUFBRUosS0FBSyxFQUFFSCxNQUFNLENBQUM7TUFDekM7SUFDSjtFQUFDO0lBQUFOLEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUFhLFVBQVVDLE1BQU0sRUFBRVosT0FBTyxFQUFFYSxRQUFRLEVBQUU7TUFDakNDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRixRQUFRLENBQUM7TUFFckIsSUFBSUcsSUFBSSxHQUFHQyxRQUFRLENBQUNDLGFBQWEsQ0FBQyxLQUFLLENBQUM7TUFDeENGLElBQUksQ0FBQ0csU0FBUyxHQUFHLCtCQUErQjtNQUVoRCxJQUFJQyxHQUFHLEdBQUdILFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztNQUN2Q0UsR0FBRyxDQUFDRCxTQUFTLEdBQUcsdUVBQXVFO01BRXZGLElBQUlFLEdBQUcsR0FBR0osUUFBUSxDQUFDQyxhQUFhLENBQUMsS0FBSyxDQUFDO01BQ3ZDRyxHQUFHLENBQUNGLFNBQVMsR0FBRyxzQ0FBc0M7TUFDdERFLEdBQUcsQ0FBQ0MsR0FBRyxHQUFHVCxRQUFRLENBQUNVLFdBQVcsQ0FBQ0MsS0FBSztNQUNwQ0gsR0FBRyxDQUFDSSxHQUFHLEdBQUdaLFFBQVEsQ0FBQ2EsSUFBSTtNQUV2Qk4sR0FBRyxDQUFDTyxXQUFXLENBQUNOLEdBQUcsQ0FBQztNQUVwQixJQUFJTyxJQUFJLEdBQUdYLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEdBQUcsQ0FBQztNQUN0Q1UsSUFBSSxDQUFDVCxTQUFTLEdBQUcsaUVBQWlFO01BQ2xGUyxJQUFJLENBQUNDLElBQUksR0FBRyxTQUFTLEdBQUdoQixRQUFRLENBQUNhLElBQUk7TUFDckNFLElBQUksQ0FBQ0UsU0FBUyxHQUFHLG9CQUFvQjtNQUVyQ2QsSUFBSSxDQUFDVyxXQUFXLENBQUNQLEdBQUcsQ0FBQztNQUNyQkosSUFBSSxDQUFDVyxXQUFXLENBQUNmLE1BQU0sQ0FBQ21CLGdCQUFnQixDQUFDbEIsUUFBUSxDQUFDLENBQUM7TUFDbkRHLElBQUksQ0FBQ1csV0FBVyxDQUFDQyxJQUFJLENBQUM7TUFDdEI1QixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMyQixXQUFXLENBQUNYLElBQUksQ0FBQztJQUNoQztFQUFDO0lBQUFuQixHQUFBO0lBQUFDLEtBQUEsRUFFRCxTQUFBaUMsaUJBQWlCbEIsUUFBUSxFQUFFO01BQ3ZCLElBQUltQixXQUFXLEdBQUdmLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztNQUMvQ2MsV0FBVyxDQUFDYixTQUFTLEdBQUcsZ0VBQWdFO01BRXhGLElBQUljLElBQUksR0FBR2hCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLElBQUksQ0FBQztNQUN2Q2UsSUFBSSxDQUFDSCxTQUFTLEdBQUdqQixRQUFRLENBQUNvQixJQUFJO01BRTlCLElBQUlQLElBQUksR0FBR1QsUUFBUSxDQUFDQyxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ3ZDUSxJQUFJLENBQUNJLFNBQVMsR0FBR2pCLFFBQVEsQ0FBQ2EsSUFBSTtNQUU5QixJQUFJUSxVQUFVLEdBQUdqQixRQUFRLENBQUNDLGFBQWEsQ0FBQyxLQUFLLENBQUM7TUFDOUNnQixVQUFVLENBQUNmLFNBQVMsR0FBRyw0RUFBNEU7TUFFbkcsSUFBSWdCLGFBQWEsR0FBR2xCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEdBQUcsQ0FBQztNQUMvQ2lCLGFBQWEsQ0FBQ0wsU0FBUyxHQUFHakIsUUFBUSxDQUFDdUIsS0FBSyxDQUFDQyxRQUFRO01BRWpELElBQUlDLFVBQVUsR0FBR3JCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLE1BQU0sQ0FBQztNQUMvQ29CLFVBQVUsQ0FBQ1IsU0FBUyxHQUFHakIsUUFBUSxDQUFDdUIsS0FBSyxDQUFDdEMsS0FBSztNQUUzQ3FDLGFBQWEsQ0FBQ1IsV0FBVyxDQUFDVyxVQUFVLENBQUM7TUFFckMsSUFBSUMsY0FBYyxHQUFHdEIsUUFBUSxDQUFDQyxhQUFhLENBQUMsR0FBRyxDQUFDO01BQ2hEcUIsY0FBYyxDQUFDVCxTQUFTLEdBQUcsS0FBSztNQUVoQyxJQUFJVSxjQUFjLEdBQUd2QixRQUFRLENBQUNDLGFBQWEsQ0FBQyxNQUFNLENBQUM7TUFDbkRzQixjQUFjLENBQUNWLFNBQVMsR0FBR2pCLFFBQVEsQ0FBQ3VCLEtBQUssQ0FBQ0ssU0FBUztNQUVuREYsY0FBYyxDQUFDRyxPQUFPLENBQUNGLGNBQWMsQ0FBQztNQUV0Q04sVUFBVSxDQUFDUCxXQUFXLENBQUNRLGFBQWEsQ0FBQztNQUNyQ0QsVUFBVSxDQUFDUCxXQUFXLENBQUNZLGNBQWMsQ0FBQztNQUV0Q1AsV0FBVyxDQUFDTCxXQUFXLENBQUNNLElBQUksQ0FBQztNQUM3QkQsV0FBVyxDQUFDTCxXQUFXLENBQUNELElBQUksQ0FBQztNQUM3Qk0sV0FBVyxDQUFDTCxXQUFXLENBQUNPLFVBQVUsQ0FBQztNQUVuQyxPQUFPRixXQUFXO0lBQ3RCO0VBQUM7SUFBQW5DLEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUFZLFlBQVlFLE1BQU0sRUFBRU4sS0FBSyxFQUFFSCxNQUFNLEVBQUU7TUFDL0JWLENBQUMsQ0FBQ2tELElBQUksQ0FBQztRQUNIVixJQUFJLEVBQUUsTUFBTTtRQUNaVyxHQUFHLEVBQUUsY0FBYztRQUNuQkMsSUFBSSxFQUFFO1VBQ0YsT0FBTyxFQUFHLEVBQUU7VUFDWixNQUFNLEVBQUdwRCxDQUFDLENBQUNhLEtBQUssQ0FBQyxDQUFDRyxHQUFHLENBQUM7UUFDMUIsQ0FBQztRQUNEcUMsT0FBTyxFQUFFLGtCQUFrQjtRQUMzQkMsUUFBUSxFQUFFLE1BQU07UUFDaEJDLFVBQVUsRUFBRTtVQUNSLEdBQUcsRUFBRSxTQUFBQyxFQUFVcEMsUUFBUSxFQUFFO1lBQ3JCLElBQUlBLFFBQVEsS0FBS3FDLFNBQVMsRUFBRTtjQUN4QixJQUFJckMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUNwQixJQUFJYixPQUFPLEdBQUdQLENBQUMsQ0FBQyxHQUFHLEdBQUdBLENBQUMsQ0FBQ2EsS0FBSyxDQUFDLENBQUNGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBRSxDQUFDO2dCQUV2RCxLQUFLLElBQUkrQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUd0QyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUN1QyxNQUFNLEVBQUVELENBQUMsRUFBRSxFQUFFO2tCQUNoRCxJQUFJRSxNQUFNLENBQUM1RCxDQUFDLENBQUNPLE9BQU8sQ0FBQyxDQUFDSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxLQUFLRCxNQUFNLEVBQUU7b0JBQ3REO2tCQUNKO2tCQUVBUyxNQUFNLENBQUNELFNBQVMsQ0FBQ0MsTUFBTSxFQUFFWixPQUFPLEVBQUVhLFFBQVEsQ0FBQ0QsTUFBTSxDQUFDdUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pEO2NBQ0o7WUFDSjtVQUNKO1FBQ0o7TUFDSixDQUFDLENBQUM7SUFDTjtFQUFDO0VBQUEsT0FBQXpELFlBQUE7QUFBQTtBQUdMLElBQUlZLEtBQUssR0FBR2IsQ0FBQyxDQUFDLHlCQUF5QixDQUFDO0FBRXhDLElBQUlhLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSzRDLFNBQVMsRUFBRTtFQUN4QixJQUFJdEMsTUFBTSxHQUFHLElBQUlsQixZQUFZLENBQUMsQ0FBQztFQUUvQkQsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUM2RCxFQUFFLENBQUMsT0FBTyxFQUFFLFlBQVk7SUFDakQxQyxNQUFNLENBQUNQLFdBQVcsQ0FBQ1osQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0VBQy9CLENBQUMsQ0FBQztBQUNOOzs7Ozs7Ozs7Ozs7QUNqSUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9hc3NldHMvYXBwLmpzIiwid2VicGFjazovLy8uL2Fzc2V0cy9zY3JpcHRzL2hvbWUvc2VhcmNoLmpzIiwid2VicGFjazovLy8uL2Fzc2V0cy9hcHAuc2Nzcz8xMTAwIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXZWxjb21lIHRvIHlvdXIgYXBwJ3MgbWFpbiBKYXZhU2NyaXB0IGZpbGUhXG4gKlxuICogV2UgcmVjb21tZW5kIGluY2x1ZGluZyB0aGUgYnVpbHQgdmVyc2lvbiBvZiB0aGlzIEphdmFTY3JpcHQgZmlsZVxuICogKGFuZCBpdHMgQ1NTIGZpbGUpIGluIHlvdXIgYmFzZSBsYXlvdXQgKGJhc2UuaHRtbC50d2lnKS5cbiAqL1xuXG4vLyBhbnkgQ1NTIHlvdSBpbXBvcnQgd2lsbCBvdXRwdXQgaW50byBhIHNpbmdsZSBjc3MgZmlsZSAoYXBwLnNjc3MgaW4gdGhpcyBjYXNlKVxuaW1wb3J0ICcuL2FwcC5zY3NzJztcblxucmVxdWlyZSgnYm9vdHN0cmFwJyk7XG5cbmltcG9ydCAnLi9zY3JpcHRzL2hvbWUvc2VhcmNoJzsiLCJjb25zdCAkID0gcmVxdWlyZSgnanF1ZXJ5Jyk7XHJcblxyXG5jbGFzcyBIZWFkZXJTZWFyY2gge1xyXG4gICAgZXJhc2VBbnN3ZXJzKGFuc3dlcnMpIHtcclxuICAgICAgICAkKCcjJyArIGFuc3dlcnMpLmVtcHR5KCk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0VW5pcVNlYXJjaChhbnN3ZXJzLCB1bmlxaWQpIHtcclxuICAgICAgICAkKCcjJyArIGFuc3dlcnMpLmF0dHIoJ2RhdGEtZmwtc2VhcmNoJywgdW5pcWlkKTtcclxuICAgIH1cclxuXHJcbiAgICBzZWFyY2hUaXRsZShpbnB1dCkge1xyXG4gICAgICAgIGxldCBhbnN3ZXJzID0gJChpbnB1dCkuYXR0cignZGF0YS1mbC10YXJnZXQnKTtcclxuXHJcbiAgICAgICAgdGhpcy5lcmFzZUFuc3dlcnMoYW5zd2Vycyk7XHJcblxyXG4gICAgICAgIGxldCB1bmlxaWQgPSBEYXRlLm5vdygpO1xyXG4gICAgICAgIHRoaXMuc2V0VW5pcVNlYXJjaChhbnN3ZXJzLCB1bmlxaWQpO1xyXG5cclxuICAgICAgICBpZiAoJChpbnB1dCkudmFsKCkgIT09IFwiXCIpIHtcclxuICAgICAgICAgICAgdGhpcy5zZW5kUmVxdWVzdCh0aGlzLCBpbnB1dCwgdW5pcWlkKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYnVpbGRDYXJkKHNlYXJjaCwgYW5zd2VycywgcmVzcG9uc2UpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcblxyXG4gICAgICAgIGxldCBjYXJkID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICAgICAgY2FyZC5jbGFzc05hbWUgPSBcImQtZmxleCB3LTEwMCBzZWFyY2hlZC1wcm9kdWN0XCI7XHJcblxyXG4gICAgICAgIGxldCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgICAgICBkaXYuY2xhc3NOYW1lID0gXCJkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGp1c3RpZnktY29udGVudC1jZW50ZXIgc2VhcmNoZWQtaW1hZ2UtYmxvY2tcIjtcclxuXHJcbiAgICAgICAgbGV0IGltZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2ltZycpO1xyXG4gICAgICAgIGltZy5jbGFzc05hbWUgPSBcIm13LTEwMCBtaC0xMDAgc2VhcmNoZWQtaW1hZ2UtY29udGVudFwiO1xyXG4gICAgICAgIGltZy5zcmMgPSByZXNwb25zZS5hdHRhY2htZW50cy5pbWFnZTtcclxuICAgICAgICBpbWcuYWx0ID0gcmVzcG9uc2UuY29kZTtcclxuXHJcbiAgICAgICAgZGl2LmFwcGVuZENoaWxkKGltZylcclxuXHJcbiAgICAgICAgbGV0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgbGluay5jbGFzc05hbWUgPSBcInctMTAwIHRleHQtZGVjb3JhdGlvbi1ub25lIGZsX2ZvbnQtZmFtaWx5LXByaW1hcnkgc2VhcmNoZWQtbGlua1wiO1xyXG4gICAgICAgIGxpbmsuaHJlZiA9IFwiL2dvb2RzL1wiICsgcmVzcG9uc2UuY29kZTtcclxuICAgICAgICBsaW5rLmlubmVySFRNTCA9IFwi0J/QvtC60LDQt9Cw0YLRjCDQv9C+0LTRgNC+0LHQvdC10LVcIjtcclxuXHJcbiAgICAgICAgY2FyZC5hcHBlbmRDaGlsZChkaXYpO1xyXG4gICAgICAgIGNhcmQuYXBwZW5kQ2hpbGQoc2VhcmNoLmJ1aWxkRGVzY3JpcHRpb24ocmVzcG9uc2UpKTtcclxuICAgICAgICBjYXJkLmFwcGVuZENoaWxkKGxpbmspO1xyXG4gICAgICAgIGFuc3dlcnNbMF0uYXBwZW5kQ2hpbGQoY2FyZCk7XHJcbiAgICB9XHJcblxyXG4gICAgYnVpbGREZXNjcmlwdGlvbihyZXNwb25zZSkge1xyXG4gICAgICAgIGxldCBkZXNjcmlwdGlvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgIGRlc2NyaXB0aW9uLmNsYXNzTmFtZSA9IFwiZC1mbGV4IGZsZXgtY29sdW1uIGZsX2ZvbnQtZmFtaWx5LXByaW1hcnkgc2VhcmNoZWQtZGVzY3JpcHRpb25cIjtcclxuXHJcbiAgICAgICAgbGV0IHR5cGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdoMicpO1xyXG4gICAgICAgIHR5cGUuaW5uZXJIVE1MID0gcmVzcG9uc2UudHlwZTtcclxuXHJcbiAgICAgICAgbGV0IGNvZGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdoMScpO1xyXG4gICAgICAgIGNvZGUuaW5uZXJIVE1MID0gcmVzcG9uc2UuY29kZTtcclxuXHJcbiAgICAgICAgbGV0IHByaWNlQmxvY2sgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgICAgICBwcmljZUJsb2NrLmNsYXNzTmFtZSA9IFwiZC1mbGV4IGp1c3RpZnktY29udGVudC1iZXR3ZWVuIHctMTAwIGZsX2ZvbnQtZmFtaWx5LXByaW1hcnkgc2VhcmNoZWQtcHJpY2VcIjtcclxuXHJcbiAgICAgICAgbGV0IHByaWNlQ3VycmVuY3kgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdwJyk7XHJcbiAgICAgICAgcHJpY2VDdXJyZW5jeS5pbm5lckhUTUwgPSByZXNwb25zZS5wcmljZS5jdXJyZW5jeTtcclxuXHJcbiAgICAgICAgbGV0IHByaWNlVmFsdWUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICAgICAgcHJpY2VWYWx1ZS5pbm5lckhUTUwgPSByZXNwb25zZS5wcmljZS52YWx1ZTtcclxuXHJcbiAgICAgICAgcHJpY2VDdXJyZW5jeS5hcHBlbmRDaGlsZChwcmljZVZhbHVlKTtcclxuXHJcbiAgICAgICAgbGV0IHdhcmVob3VzZUNvdW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncCcpO1xyXG4gICAgICAgIHdhcmVob3VzZUNvdW50LmlubmVySFRNTCA9IFwi0YjRgi5cIjtcclxuXHJcbiAgICAgICAgbGV0IHdhcmVob3VzZVZhbHVlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgICAgIHdhcmVob3VzZVZhbHVlLmlubmVySFRNTCA9IHJlc3BvbnNlLnByaWNlLndhcmVob3VzZTtcclxuXHJcbiAgICAgICAgd2FyZWhvdXNlQ291bnQucHJlcGVuZCh3YXJlaG91c2VWYWx1ZSk7XHJcblxyXG4gICAgICAgIHByaWNlQmxvY2suYXBwZW5kQ2hpbGQocHJpY2VDdXJyZW5jeSk7XHJcbiAgICAgICAgcHJpY2VCbG9jay5hcHBlbmRDaGlsZCh3YXJlaG91c2VDb3VudCk7XHJcblxyXG4gICAgICAgIGRlc2NyaXB0aW9uLmFwcGVuZENoaWxkKHR5cGUpO1xyXG4gICAgICAgIGRlc2NyaXB0aW9uLmFwcGVuZENoaWxkKGNvZGUpO1xyXG4gICAgICAgIGRlc2NyaXB0aW9uLmFwcGVuZENoaWxkKHByaWNlQmxvY2spO1xyXG5cclxuICAgICAgICByZXR1cm4gZGVzY3JpcHRpb247XHJcbiAgICB9XHJcblxyXG4gICAgc2VuZFJlcXVlc3Qoc2VhcmNoLCBpbnB1dCwgdW5pcWlkKSB7XHJcbiAgICAgICAgJC5hamF4KHtcclxuICAgICAgICAgICAgdHlwZTogXCJQT1NUXCIsXHJcbiAgICAgICAgICAgIHVybDogXCIvc2VhcmNoL2Z1bGxcIixcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgXCJsaW1pdFwiIDogMjQsXHJcbiAgICAgICAgICAgICAgICBcImNvZGVcIiA6ICQoaW5wdXQpLnZhbCgpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGVuY3R5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgZGF0YVR5cGU6ICdqc29uJyxcclxuICAgICAgICAgICAgc3RhdHVzQ29kZToge1xyXG4gICAgICAgICAgICAgICAgMjAwOiBmdW5jdGlvbiAocmVzcG9uc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2VbJ3NlYXJjaCddKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYW5zd2VycyA9ICQoJyMnICsgJChpbnB1dCkuYXR0cignZGF0YS1mbC10YXJnZXQnKSApO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzcG9uc2VbJ3NlYXJjaCddLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKE51bWJlcigkKGFuc3dlcnMpLmF0dHIoJ2RhdGEtZmwtc2VhcmNoJykpICE9PSB1bmlxaWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoLmJ1aWxkQ2FyZChzZWFyY2gsIGFuc3dlcnMsIHJlc3BvbnNlLnNlYXJjaFtpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmxldCBpbnB1dCA9ICQoXCJpbnB1dFtuYW1lPXNlYXJjaElucHV0XVwiKTtcclxuXHJcbmlmIChpbnB1dFswXSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICBsZXQgc2VhcmNoID0gbmV3IEhlYWRlclNlYXJjaCgpO1xyXG5cclxuICAgICQoXCJpbnB1dFtuYW1lPXNlYXJjaElucHV0XVwiKS5vbignaW5wdXQnLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgc2VhcmNoLnNlYXJjaFRpdGxlKCQodGhpcykpXHJcbiAgICB9KTtcclxufVxyXG4iLCIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbmV4cG9ydCB7fTsiXSwibmFtZXMiOlsicmVxdWlyZSIsIiQiLCJIZWFkZXJTZWFyY2giLCJfY2xhc3NDYWxsQ2hlY2siLCJfY3JlYXRlQ2xhc3MiLCJrZXkiLCJ2YWx1ZSIsImVyYXNlQW5zd2VycyIsImFuc3dlcnMiLCJlbXB0eSIsInNldFVuaXFTZWFyY2giLCJ1bmlxaWQiLCJhdHRyIiwic2VhcmNoVGl0bGUiLCJpbnB1dCIsIkRhdGUiLCJub3ciLCJ2YWwiLCJzZW5kUmVxdWVzdCIsImJ1aWxkQ2FyZCIsInNlYXJjaCIsInJlc3BvbnNlIiwiY29uc29sZSIsImxvZyIsImNhcmQiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJjbGFzc05hbWUiLCJkaXYiLCJpbWciLCJzcmMiLCJhdHRhY2htZW50cyIsImltYWdlIiwiYWx0IiwiY29kZSIsImFwcGVuZENoaWxkIiwibGluayIsImhyZWYiLCJpbm5lckhUTUwiLCJidWlsZERlc2NyaXB0aW9uIiwiZGVzY3JpcHRpb24iLCJ0eXBlIiwicHJpY2VCbG9jayIsInByaWNlQ3VycmVuY3kiLCJwcmljZSIsImN1cnJlbmN5IiwicHJpY2VWYWx1ZSIsIndhcmVob3VzZUNvdW50Iiwid2FyZWhvdXNlVmFsdWUiLCJ3YXJlaG91c2UiLCJwcmVwZW5kIiwiYWpheCIsInVybCIsImRhdGEiLCJlbmN0eXBlIiwiZGF0YVR5cGUiLCJzdGF0dXNDb2RlIiwiXyIsInVuZGVmaW5lZCIsImkiLCJsZW5ndGgiLCJOdW1iZXIiLCJvbiJdLCJzb3VyY2VSb290IjoiIn0=