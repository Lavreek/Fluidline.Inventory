(self["webpackChunk"] = self["webpackChunk"] || []).push([["app"],{

/***/ "./assets/app.js":
/*!***********************!*\
  !*** ./assets/app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _app_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.scss */ "./assets/app.scss");
/* harmony import */ var _scripts_home_search__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./scripts/home/search */ "./assets/scripts/home/search.js");
/* harmony import */ var _scripts_home_search__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_scripts_home_search__WEBPACK_IMPORTED_MODULE_1__);
/*
 * Welcome to your app's main JavaScript file!
 *
 * We recommend including the built version of this JavaScript file
 * (and its CSS file) in your base layout (base.html.twig).
 */

// any CSS you import will output into a single css file (app.scss in this case)

__webpack_require__(/*! bootstrap */ "./node_modules/bootstrap/dist/js/bootstrap.esm.js");
var $ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");


/***/ }),

/***/ "./assets/scripts/home/search.js":
/*!***************************************!*\
  !*** ./assets/scripts/home/search.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
__webpack_require__(/*! core-js/modules/es.date.now.js */ "./node_modules/core-js/modules/es.date.now.js");
__webpack_require__(/*! core-js/modules/es.date.to-string.js */ "./node_modules/core-js/modules/es.date.to-string.js");
__webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
__webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
__webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
__webpack_require__(/*! core-js/modules/es.symbol.to-primitive.js */ "./node_modules/core-js/modules/es.symbol.to-primitive.js");
__webpack_require__(/*! core-js/modules/es.date.to-primitive.js */ "./node_modules/core-js/modules/es.date.to-primitive.js");
__webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
__webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
__webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
__webpack_require__(/*! core-js/modules/es.error.cause.js */ "./node_modules/core-js/modules/es.error.cause.js");
__webpack_require__(/*! core-js/modules/es.error.to-string.js */ "./node_modules/core-js/modules/es.error.to-string.js");
__webpack_require__(/*! core-js/modules/es.object.define-property.js */ "./node_modules/core-js/modules/es.object.define-property.js");
__webpack_require__(/*! core-js/modules/es.symbol.iterator.js */ "./node_modules/core-js/modules/es.symbol.iterator.js");
__webpack_require__(/*! core-js/modules/es.array.iterator.js */ "./node_modules/core-js/modules/es.array.iterator.js");
__webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
__webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var HeaderSearch = /*#__PURE__*/function () {
  "use strict";

  function HeaderSearch() {
    _classCallCheck(this, HeaderSearch);
  }
  _createClass(HeaderSearch, [{
    key: "eraseAnswers",
    value: function eraseAnswers(answers) {
      $('#' + answers).empty();
    }
  }, {
    key: "setUniqSearch",
    value: function setUniqSearch(answers, uniqid) {
      $('#' + answers).attr('data-fl-search', uniqid);
    }
  }, {
    key: "searchTitle",
    value: function searchTitle(input) {
      var answers = $(input).attr('data-fl-target');
      this.eraseAnswers(answers);
      var uniqid = Date.now();
      this.setUniqSearch(answers, uniqid);
      if ($(input).val() !== "") {
        this.sendRequest(this, input, uniqid);
      }
    }
  }, {
    key: "buildCard",
    value: function buildCard(search, answers, response) {
      console.log(response);
      var card = document.createElement('div');
      card.className = "fl_display-flex fl_width-100 searched-product";
      var img = document.createElement('img');
      img.className = "searched-image";
      img.src = response.attachments.image;
      img.alt = response.code;
      var link = document.createElement('a');
      link.className = "fl_width-100 fl_text-decoration-none fl_font-family-primary searched-link";
      link.href = "/goods/" + response.code;
      link.innerHTML = "Показать подробнее";
      card.appendChild(img);
      card.appendChild(search.buildDescription(response));
      card.appendChild(link);
      answers[0].appendChild(card);
    }
  }, {
    key: "buildDescription",
    value: function buildDescription(response) {
      var description = document.createElement('div');
      description.className = "fl_display-flex fl_flex-direction-column fl_font-family-primary searched-description";
      var type = document.createElement('h2');
      type.innerHTML = response.type;
      var code = document.createElement('h1');
      code.innerHTML = response.code;
      var priceBlock = document.createElement('div');
      priceBlock.className = "fl_display-flex fl_font-family-primary fl_justify-content-space-between fl_width-100 searched-price";
      var priceCurrency = document.createElement('p');
      priceCurrency.innerHTML = response.price.currency;
      var priceValue = document.createElement('span');
      priceValue.innerHTML = response.price.value;
      priceCurrency.appendChild(priceValue);
      var warehouseCount = document.createElement('p');
      warehouseCount.innerHTML = "шт.";
      var warehouseValue = document.createElement('span');
      warehouseValue.innerHTML = response.price.warehouse;
      warehouseCount.prepend(warehouseValue);
      priceBlock.appendChild(priceCurrency);
      priceBlock.appendChild(warehouseCount);
      description.appendChild(type);
      description.appendChild(code);
      description.appendChild(priceBlock);
      return description;
    }
  }, {
    key: "sendRequest",
    value: function sendRequest(search, input, uniqid) {
      $.ajax({
        type: "POST",
        url: "/search/full",
        data: {
          "code": $(input).val()
        },
        enctype: 'application/json',
        dataType: 'json',
        statusCode: {
          200: function _(response) {
            if (response !== undefined) {
              if (response['search']) {
                var answers = $('#' + $(input).attr('data-fl-target'));
                for (var i = 0; i < response['search'].length; i++) {
                  if (Number($(answers).attr('data-fl-search')) !== uniqid) {
                    return;
                  }
                  search.buildCard(search, answers, response.search[i]);
                }
              }
            }
          }
        }
      });
    }
  }]);
  return HeaderSearch;
}();
var input = $("input[name=searchInput]");
if (input[0] !== undefined) {
  var search = new HeaderSearch();
  $("input[name=searchInput]").on('input', function () {
    search.searchTitle($(this));
  });
}

/***/ }),

/***/ "./assets/app.scss":
/*!*************************!*\
  !*** ./assets/app.scss ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendors-node_modules_bootstrap_dist_js_bootstrap_esm_js-node_modules_jquery_dist_jquery_js-no-e404aa"], () => (__webpack_exec__("./assets/app.js")));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDb0I7QUFFcEJBLG1CQUFPLENBQUMsb0VBQVcsQ0FBQztBQUVwQixJQUFNQyxDQUFDLEdBQUdELG1CQUFPLENBQUMsb0RBQVEsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQ1pyQkUsWUFBWTtFQUFBOztFQUFBLFNBQUFBLGFBQUE7SUFBQUMsZUFBQSxPQUFBRCxZQUFBO0VBQUE7RUFBQUUsWUFBQSxDQUFBRixZQUFBO0lBQUFHLEdBQUE7SUFBQUMsS0FBQSxFQUNkLFNBQUFDLGFBQWFDLE9BQU8sRUFBRTtNQUNsQlAsQ0FBQyxDQUFDLEdBQUcsR0FBR08sT0FBTyxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzVCO0VBQUM7SUFBQUosR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQUksY0FBY0YsT0FBTyxFQUFFRyxNQUFNLEVBQUU7TUFDM0JWLENBQUMsQ0FBQyxHQUFHLEdBQUdPLE9BQU8sQ0FBQyxDQUFDSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUVELE1BQU0sQ0FBQztJQUNuRDtFQUFDO0lBQUFOLEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUFPLFlBQVlDLEtBQUssRUFBRTtNQUNmLElBQUlOLE9BQU8sR0FBR1AsQ0FBQyxDQUFDYSxLQUFLLENBQUMsQ0FBQ0YsSUFBSSxDQUFDLGdCQUFnQixDQUFDO01BRTdDLElBQUksQ0FBQ0wsWUFBWSxDQUFDQyxPQUFPLENBQUM7TUFFMUIsSUFBSUcsTUFBTSxHQUFHSSxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDO01BQ3ZCLElBQUksQ0FBQ04sYUFBYSxDQUFDRixPQUFPLEVBQUVHLE1BQU0sQ0FBQztNQUVuQyxJQUFJVixDQUFDLENBQUNhLEtBQUssQ0FBQyxDQUFDRyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRTtRQUN2QixJQUFJLENBQUNDLFdBQVcsQ0FBQyxJQUFJLEVBQUVKLEtBQUssRUFBRUgsTUFBTSxDQUFDO01BQ3pDO0lBQ0o7RUFBQztJQUFBTixHQUFBO0lBQUFDLEtBQUEsRUFFRCxTQUFBYSxVQUFVQyxNQUFNLEVBQUVaLE9BQU8sRUFBRWEsUUFBUSxFQUFFO01BQ2pDQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0YsUUFBUSxDQUFDO01BRXJCLElBQUlHLElBQUksR0FBR0MsUUFBUSxDQUFDQyxhQUFhLENBQUMsS0FBSyxDQUFDO01BQ3hDRixJQUFJLENBQUNHLFNBQVMsR0FBRywrQ0FBK0M7TUFFaEUsSUFBSUMsR0FBRyxHQUFHSCxRQUFRLENBQUNDLGFBQWEsQ0FBQyxLQUFLLENBQUM7TUFDdkNFLEdBQUcsQ0FBQ0QsU0FBUyxHQUFHLGdCQUFnQjtNQUNoQ0MsR0FBRyxDQUFDQyxHQUFHLEdBQUdSLFFBQVEsQ0FBQ1MsV0FBVyxDQUFDQyxLQUFLO01BQ3BDSCxHQUFHLENBQUNJLEdBQUcsR0FBR1gsUUFBUSxDQUFDWSxJQUFJO01BRXZCLElBQUlDLElBQUksR0FBR1QsUUFBUSxDQUFDQyxhQUFhLENBQUMsR0FBRyxDQUFDO01BQ3RDUSxJQUFJLENBQUNQLFNBQVMsR0FBRywyRUFBMkU7TUFDNUZPLElBQUksQ0FBQ0MsSUFBSSxHQUFHLFNBQVMsR0FBR2QsUUFBUSxDQUFDWSxJQUFJO01BQ3JDQyxJQUFJLENBQUNFLFNBQVMsR0FBRyxvQkFBb0I7TUFFckNaLElBQUksQ0FBQ2EsV0FBVyxDQUFDVCxHQUFHLENBQUM7TUFDckJKLElBQUksQ0FBQ2EsV0FBVyxDQUFDakIsTUFBTSxDQUFDa0IsZ0JBQWdCLENBQUNqQixRQUFRLENBQUMsQ0FBQztNQUNuREcsSUFBSSxDQUFDYSxXQUFXLENBQUNILElBQUksQ0FBQztNQUN0QjFCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzZCLFdBQVcsQ0FBQ2IsSUFBSSxDQUFDO0lBQ2hDO0VBQUM7SUFBQW5CLEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUFnQyxpQkFBaUJqQixRQUFRLEVBQUU7TUFDdkIsSUFBSWtCLFdBQVcsR0FBR2QsUUFBUSxDQUFDQyxhQUFhLENBQUMsS0FBSyxDQUFDO01BQy9DYSxXQUFXLENBQUNaLFNBQVMsR0FBRyxzRkFBc0Y7TUFFOUcsSUFBSWEsSUFBSSxHQUFHZixRQUFRLENBQUNDLGFBQWEsQ0FBQyxJQUFJLENBQUM7TUFDdkNjLElBQUksQ0FBQ0osU0FBUyxHQUFHZixRQUFRLENBQUNtQixJQUFJO01BRTlCLElBQUlQLElBQUksR0FBR1IsUUFBUSxDQUFDQyxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ3ZDTyxJQUFJLENBQUNHLFNBQVMsR0FBR2YsUUFBUSxDQUFDWSxJQUFJO01BRTlCLElBQUlRLFVBQVUsR0FBR2hCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztNQUM5Q2UsVUFBVSxDQUFDZCxTQUFTLEdBQUcscUdBQXFHO01BRTVILElBQUllLGFBQWEsR0FBR2pCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEdBQUcsQ0FBQztNQUMvQ2dCLGFBQWEsQ0FBQ04sU0FBUyxHQUFHZixRQUFRLENBQUNzQixLQUFLLENBQUNDLFFBQVE7TUFFakQsSUFBSUMsVUFBVSxHQUFHcEIsUUFBUSxDQUFDQyxhQUFhLENBQUMsTUFBTSxDQUFDO01BQy9DbUIsVUFBVSxDQUFDVCxTQUFTLEdBQUdmLFFBQVEsQ0FBQ3NCLEtBQUssQ0FBQ3JDLEtBQUs7TUFFM0NvQyxhQUFhLENBQUNMLFdBQVcsQ0FBQ1EsVUFBVSxDQUFDO01BRXJDLElBQUlDLGNBQWMsR0FBR3JCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEdBQUcsQ0FBQztNQUNoRG9CLGNBQWMsQ0FBQ1YsU0FBUyxHQUFHLEtBQUs7TUFFaEMsSUFBSVcsY0FBYyxHQUFHdEIsUUFBUSxDQUFDQyxhQUFhLENBQUMsTUFBTSxDQUFDO01BQ25EcUIsY0FBYyxDQUFDWCxTQUFTLEdBQUdmLFFBQVEsQ0FBQ3NCLEtBQUssQ0FBQ0ssU0FBUztNQUVuREYsY0FBYyxDQUFDRyxPQUFPLENBQUNGLGNBQWMsQ0FBQztNQUV0Q04sVUFBVSxDQUFDSixXQUFXLENBQUNLLGFBQWEsQ0FBQztNQUNyQ0QsVUFBVSxDQUFDSixXQUFXLENBQUNTLGNBQWMsQ0FBQztNQUV0Q1AsV0FBVyxDQUFDRixXQUFXLENBQUNHLElBQUksQ0FBQztNQUM3QkQsV0FBVyxDQUFDRixXQUFXLENBQUNKLElBQUksQ0FBQztNQUM3Qk0sV0FBVyxDQUFDRixXQUFXLENBQUNJLFVBQVUsQ0FBQztNQUVuQyxPQUFPRixXQUFXO0lBQ3RCO0VBQUM7SUFBQWxDLEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUFZLFlBQVlFLE1BQU0sRUFBRU4sS0FBSyxFQUFFSCxNQUFNLEVBQUU7TUFDL0JWLENBQUMsQ0FBQ2lELElBQUksQ0FBQztRQUNIVixJQUFJLEVBQUUsTUFBTTtRQUNaVyxHQUFHLEVBQUUsY0FBYztRQUNuQkMsSUFBSSxFQUFFO1VBQ0YsTUFBTSxFQUFFbkQsQ0FBQyxDQUFDYSxLQUFLLENBQUMsQ0FBQ0csR0FBRyxDQUFDO1FBQ3pCLENBQUM7UUFDRG9DLE9BQU8sRUFBRSxrQkFBa0I7UUFDM0JDLFFBQVEsRUFBRSxNQUFNO1FBQ2hCQyxVQUFVLEVBQUU7VUFDUixHQUFHLEVBQUUsU0FBQUMsRUFBVW5DLFFBQVEsRUFBRTtZQUNyQixJQUFJQSxRQUFRLEtBQUtvQyxTQUFTLEVBQUU7Y0FDeEIsSUFBSXBDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDcEIsSUFBSWIsT0FBTyxHQUFHUCxDQUFDLENBQUMsR0FBRyxHQUFHQSxDQUFDLENBQUNhLEtBQUssQ0FBQyxDQUFDRixJQUFJLENBQUMsZ0JBQWdCLENBQUUsQ0FBQztnQkFFdkQsS0FBSyxJQUFJOEMsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHckMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDc0MsTUFBTSxFQUFFRCxDQUFDLEVBQUUsRUFBRTtrQkFDaEQsSUFBSUUsTUFBTSxDQUFDM0QsQ0FBQyxDQUFDTyxPQUFPLENBQUMsQ0FBQ0ksSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsS0FBS0QsTUFBTSxFQUFFO29CQUN0RDtrQkFDSjtrQkFFQVMsTUFBTSxDQUFDRCxTQUFTLENBQUNDLE1BQU0sRUFBRVosT0FBTyxFQUFFYSxRQUFRLENBQUNELE1BQU0sQ0FBQ3NDLENBQUMsQ0FBQyxDQUFDO2dCQUN6RDtjQUNKO1lBQ0o7VUFDSjtRQUNKO01BQ0osQ0FBQyxDQUFDO0lBQ047RUFBQztFQUFBLE9BQUF4RCxZQUFBO0FBQUE7QUFHTCxJQUFJWSxLQUFLLEdBQUdiLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQztBQUV4QyxJQUFJYSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUsyQyxTQUFTLEVBQUU7RUFDeEIsSUFBSXJDLE1BQU0sR0FBRyxJQUFJbEIsWUFBWSxDQUFDLENBQUM7RUFFL0JELENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDNEQsRUFBRSxDQUFDLE9BQU8sRUFBRSxZQUFZO0lBQ2pEekMsTUFBTSxDQUFDUCxXQUFXLENBQUNaLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUMvQixDQUFDLENBQUM7QUFDTjs7Ozs7Ozs7Ozs7O0FDekhBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vYXNzZXRzL2FwcC5qcyIsIndlYnBhY2s6Ly8vLi9hc3NldHMvc2NyaXB0cy9ob21lL3NlYXJjaC5qcyIsIndlYnBhY2s6Ly8vLi9hc3NldHMvYXBwLnNjc3M/MTEwMCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2VsY29tZSB0byB5b3VyIGFwcCdzIG1haW4gSmF2YVNjcmlwdCBmaWxlIVxuICpcbiAqIFdlIHJlY29tbWVuZCBpbmNsdWRpbmcgdGhlIGJ1aWx0IHZlcnNpb24gb2YgdGhpcyBKYXZhU2NyaXB0IGZpbGVcbiAqIChhbmQgaXRzIENTUyBmaWxlKSBpbiB5b3VyIGJhc2UgbGF5b3V0IChiYXNlLmh0bWwudHdpZykuXG4gKi9cblxuLy8gYW55IENTUyB5b3UgaW1wb3J0IHdpbGwgb3V0cHV0IGludG8gYSBzaW5nbGUgY3NzIGZpbGUgKGFwcC5zY3NzIGluIHRoaXMgY2FzZSlcbmltcG9ydCAnLi9hcHAuc2Nzcyc7XG5cbnJlcXVpcmUoJ2Jvb3RzdHJhcCcpO1xuXG5jb25zdCAkID0gcmVxdWlyZSgnanF1ZXJ5Jyk7XG5cbmltcG9ydCAnLi9zY3JpcHRzL2hvbWUvc2VhcmNoJyIsImNsYXNzIEhlYWRlclNlYXJjaCB7XHJcbiAgICBlcmFzZUFuc3dlcnMoYW5zd2Vycykge1xyXG4gICAgICAgICQoJyMnICsgYW5zd2VycykuZW1wdHkoKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRVbmlxU2VhcmNoKGFuc3dlcnMsIHVuaXFpZCkge1xyXG4gICAgICAgICQoJyMnICsgYW5zd2VycykuYXR0cignZGF0YS1mbC1zZWFyY2gnLCB1bmlxaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHNlYXJjaFRpdGxlKGlucHV0KSB7XHJcbiAgICAgICAgbGV0IGFuc3dlcnMgPSAkKGlucHV0KS5hdHRyKCdkYXRhLWZsLXRhcmdldCcpO1xyXG5cclxuICAgICAgICB0aGlzLmVyYXNlQW5zd2VycyhhbnN3ZXJzKTtcclxuXHJcbiAgICAgICAgbGV0IHVuaXFpZCA9IERhdGUubm93KCk7XHJcbiAgICAgICAgdGhpcy5zZXRVbmlxU2VhcmNoKGFuc3dlcnMsIHVuaXFpZCk7XHJcblxyXG4gICAgICAgIGlmICgkKGlucHV0KS52YWwoKSAhPT0gXCJcIikge1xyXG4gICAgICAgICAgICB0aGlzLnNlbmRSZXF1ZXN0KHRoaXMsIGlucHV0LCB1bmlxaWQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBidWlsZENhcmQoc2VhcmNoLCBhbnN3ZXJzLCByZXNwb25zZSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuXHJcbiAgICAgICAgbGV0IGNhcmQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgICAgICBjYXJkLmNsYXNzTmFtZSA9IFwiZmxfZGlzcGxheS1mbGV4IGZsX3dpZHRoLTEwMCBzZWFyY2hlZC1wcm9kdWN0XCI7XHJcblxyXG4gICAgICAgIGxldCBpbWcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpbWcnKTtcclxuICAgICAgICBpbWcuY2xhc3NOYW1lID0gXCJzZWFyY2hlZC1pbWFnZVwiO1xyXG4gICAgICAgIGltZy5zcmMgPSByZXNwb25zZS5hdHRhY2htZW50cy5pbWFnZTtcclxuICAgICAgICBpbWcuYWx0ID0gcmVzcG9uc2UuY29kZTtcclxuXHJcbiAgICAgICAgbGV0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgbGluay5jbGFzc05hbWUgPSBcImZsX3dpZHRoLTEwMCBmbF90ZXh0LWRlY29yYXRpb24tbm9uZSBmbF9mb250LWZhbWlseS1wcmltYXJ5IHNlYXJjaGVkLWxpbmtcIjtcclxuICAgICAgICBsaW5rLmhyZWYgPSBcIi9nb29kcy9cIiArIHJlc3BvbnNlLmNvZGU7XHJcbiAgICAgICAgbGluay5pbm5lckhUTUwgPSBcItCf0L7QutCw0LfQsNGC0Ywg0L/QvtC00YDQvtCx0L3QtdC1XCI7XHJcblxyXG4gICAgICAgIGNhcmQuYXBwZW5kQ2hpbGQoaW1nKTtcclxuICAgICAgICBjYXJkLmFwcGVuZENoaWxkKHNlYXJjaC5idWlsZERlc2NyaXB0aW9uKHJlc3BvbnNlKSk7XHJcbiAgICAgICAgY2FyZC5hcHBlbmRDaGlsZChsaW5rKTtcclxuICAgICAgICBhbnN3ZXJzWzBdLmFwcGVuZENoaWxkKGNhcmQpO1xyXG4gICAgfVxyXG5cclxuICAgIGJ1aWxkRGVzY3JpcHRpb24ocmVzcG9uc2UpIHtcclxuICAgICAgICBsZXQgZGVzY3JpcHRpb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgICAgICBkZXNjcmlwdGlvbi5jbGFzc05hbWUgPSBcImZsX2Rpc3BsYXktZmxleCBmbF9mbGV4LWRpcmVjdGlvbi1jb2x1bW4gZmxfZm9udC1mYW1pbHktcHJpbWFyeSBzZWFyY2hlZC1kZXNjcmlwdGlvblwiO1xyXG5cclxuICAgICAgICBsZXQgdHlwZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2gyJyk7XHJcbiAgICAgICAgdHlwZS5pbm5lckhUTUwgPSByZXNwb25zZS50eXBlO1xyXG5cclxuICAgICAgICBsZXQgY29kZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2gxJyk7XHJcbiAgICAgICAgY29kZS5pbm5lckhUTUwgPSByZXNwb25zZS5jb2RlO1xyXG5cclxuICAgICAgICBsZXQgcHJpY2VCbG9jayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgIHByaWNlQmxvY2suY2xhc3NOYW1lID0gXCJmbF9kaXNwbGF5LWZsZXggZmxfZm9udC1mYW1pbHktcHJpbWFyeSBmbF9qdXN0aWZ5LWNvbnRlbnQtc3BhY2UtYmV0d2VlbiBmbF93aWR0aC0xMDAgc2VhcmNoZWQtcHJpY2VcIjtcclxuXHJcbiAgICAgICAgbGV0IHByaWNlQ3VycmVuY3kgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdwJyk7XHJcbiAgICAgICAgcHJpY2VDdXJyZW5jeS5pbm5lckhUTUwgPSByZXNwb25zZS5wcmljZS5jdXJyZW5jeTtcclxuXHJcbiAgICAgICAgbGV0IHByaWNlVmFsdWUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICAgICAgcHJpY2VWYWx1ZS5pbm5lckhUTUwgPSByZXNwb25zZS5wcmljZS52YWx1ZTtcclxuXHJcbiAgICAgICAgcHJpY2VDdXJyZW5jeS5hcHBlbmRDaGlsZChwcmljZVZhbHVlKTtcclxuXHJcbiAgICAgICAgbGV0IHdhcmVob3VzZUNvdW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncCcpO1xyXG4gICAgICAgIHdhcmVob3VzZUNvdW50LmlubmVySFRNTCA9IFwi0YjRgi5cIjtcclxuXHJcbiAgICAgICAgbGV0IHdhcmVob3VzZVZhbHVlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgICAgIHdhcmVob3VzZVZhbHVlLmlubmVySFRNTCA9IHJlc3BvbnNlLnByaWNlLndhcmVob3VzZTtcclxuXHJcbiAgICAgICAgd2FyZWhvdXNlQ291bnQucHJlcGVuZCh3YXJlaG91c2VWYWx1ZSk7XHJcblxyXG4gICAgICAgIHByaWNlQmxvY2suYXBwZW5kQ2hpbGQocHJpY2VDdXJyZW5jeSk7XHJcbiAgICAgICAgcHJpY2VCbG9jay5hcHBlbmRDaGlsZCh3YXJlaG91c2VDb3VudCk7XHJcblxyXG4gICAgICAgIGRlc2NyaXB0aW9uLmFwcGVuZENoaWxkKHR5cGUpO1xyXG4gICAgICAgIGRlc2NyaXB0aW9uLmFwcGVuZENoaWxkKGNvZGUpO1xyXG4gICAgICAgIGRlc2NyaXB0aW9uLmFwcGVuZENoaWxkKHByaWNlQmxvY2spO1xyXG5cclxuICAgICAgICByZXR1cm4gZGVzY3JpcHRpb247XHJcbiAgICB9XHJcblxyXG4gICAgc2VuZFJlcXVlc3Qoc2VhcmNoLCBpbnB1dCwgdW5pcWlkKSB7XHJcbiAgICAgICAgJC5hamF4KHtcclxuICAgICAgICAgICAgdHlwZTogXCJQT1NUXCIsXHJcbiAgICAgICAgICAgIHVybDogXCIvc2VhcmNoL2Z1bGxcIixcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgXCJjb2RlXCI6ICQoaW5wdXQpLnZhbCgpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGVuY3R5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgZGF0YVR5cGU6ICdqc29uJyxcclxuICAgICAgICAgICAgc3RhdHVzQ29kZToge1xyXG4gICAgICAgICAgICAgICAgMjAwOiBmdW5jdGlvbiAocmVzcG9uc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2VbJ3NlYXJjaCddKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYW5zd2VycyA9ICQoJyMnICsgJChpbnB1dCkuYXR0cignZGF0YS1mbC10YXJnZXQnKSApO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzcG9uc2VbJ3NlYXJjaCddLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKE51bWJlcigkKGFuc3dlcnMpLmF0dHIoJ2RhdGEtZmwtc2VhcmNoJykpICE9PSB1bmlxaWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoLmJ1aWxkQ2FyZChzZWFyY2gsIGFuc3dlcnMsIHJlc3BvbnNlLnNlYXJjaFtpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmxldCBpbnB1dCA9ICQoXCJpbnB1dFtuYW1lPXNlYXJjaElucHV0XVwiKTtcclxuXHJcbmlmIChpbnB1dFswXSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICBsZXQgc2VhcmNoID0gbmV3IEhlYWRlclNlYXJjaCgpO1xyXG5cclxuICAgICQoXCJpbnB1dFtuYW1lPXNlYXJjaElucHV0XVwiKS5vbignaW5wdXQnLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgc2VhcmNoLnNlYXJjaFRpdGxlKCQodGhpcykpXHJcbiAgICB9KTtcclxufVxyXG4iLCIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbmV4cG9ydCB7fTsiXSwibmFtZXMiOlsicmVxdWlyZSIsIiQiLCJIZWFkZXJTZWFyY2giLCJfY2xhc3NDYWxsQ2hlY2siLCJfY3JlYXRlQ2xhc3MiLCJrZXkiLCJ2YWx1ZSIsImVyYXNlQW5zd2VycyIsImFuc3dlcnMiLCJlbXB0eSIsInNldFVuaXFTZWFyY2giLCJ1bmlxaWQiLCJhdHRyIiwic2VhcmNoVGl0bGUiLCJpbnB1dCIsIkRhdGUiLCJub3ciLCJ2YWwiLCJzZW5kUmVxdWVzdCIsImJ1aWxkQ2FyZCIsInNlYXJjaCIsInJlc3BvbnNlIiwiY29uc29sZSIsImxvZyIsImNhcmQiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJjbGFzc05hbWUiLCJpbWciLCJzcmMiLCJhdHRhY2htZW50cyIsImltYWdlIiwiYWx0IiwiY29kZSIsImxpbmsiLCJocmVmIiwiaW5uZXJIVE1MIiwiYXBwZW5kQ2hpbGQiLCJidWlsZERlc2NyaXB0aW9uIiwiZGVzY3JpcHRpb24iLCJ0eXBlIiwicHJpY2VCbG9jayIsInByaWNlQ3VycmVuY3kiLCJwcmljZSIsImN1cnJlbmN5IiwicHJpY2VWYWx1ZSIsIndhcmVob3VzZUNvdW50Iiwid2FyZWhvdXNlVmFsdWUiLCJ3YXJlaG91c2UiLCJwcmVwZW5kIiwiYWpheCIsInVybCIsImRhdGEiLCJlbmN0eXBlIiwiZGF0YVR5cGUiLCJzdGF0dXNDb2RlIiwiXyIsInVuZGVmaW5lZCIsImkiLCJsZW5ndGgiLCJOdW1iZXIiLCJvbiJdLCJzb3VyY2VSb290IjoiIn0=